package Principal;

import vista.IngresoUsuarios;

public class Principal {

	public static void main(String[] args) {
		
		
		IngresoUsuarios frame = new IngresoUsuarios();
		frame.setVisible(true);

	}

}
