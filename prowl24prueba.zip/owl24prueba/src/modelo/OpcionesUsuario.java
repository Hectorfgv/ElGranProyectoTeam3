package modelo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JComboBox;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import modelo.Usuario;

public class OpcionesUsuario {
	
		private int userid;
		private boolean admin=false;
		private String cuenta;
		private String nombre;
		private String apellido1;
		private String apellido2;
		private String edad;
		private String poblacion;
		private String email;
		private String pasword;
		private Connection conexion;
		private Statement orden = null;
		
		public OpcionesUsuario(java.sql.Connection conexion2) {
			this.conexion=(Connection) conexion2;
		}
		
		public void insertarUsuario(String nombre,String email,String pasword){
			try{
				orden = (Statement) conexion.createStatement();
			    String sql = "INSERT INTO usuarios (cuenta,email,pasword) " +
			                   "VALUES ('"+nombre+"', '"+email+"', '"+pasword+"')";
			    orden.executeUpdate(sql);
			    System.out.println("Usuario registrado con exito");
			    
			   }catch(SQLException se){
				     
				      se.printStackTrace();
			   }catch(Exception e){
				     
				      e.printStackTrace();
			   }finally{
				      
				      try{
				         if(orden!=null)
				        	 conexion.close();
				      }catch(SQLException se){
				    	  se.printStackTrace();
				      }
				      try{
				         if(conexion!=null)
				        	 conexion.close();
				      	 }catch(SQLException se){
				         se.printStackTrace();
				      }
				}
		}
		
		public Usuario buscarUsuario(String cuenta, String pass){
			ResultSet rs;
			Usuario u=new Usuario();
			try{
			  orden = (Statement) conexion.createStatement();
		      String sql = "SELECT cuenta FROM usuario WHERE nombre='"+cuenta+"'";
		      String sql2 = "SELECT pasword FROM usuario WHERE cuenta='"+cuenta+"'";
		      rs = orden.executeQuery(sql);
		     
		      while(rs.next()){
		    	  u.setCuenta(rs.getString("cuenta"));
			      u.setPasword(rs.getString("pasword"));
			     
			    
			
		      }
		     
		      
		      return u;
			}catch(SQLException se){
				     
				      se.printStackTrace();
				      return u;
			}catch(Exception e){
				      
				      e.printStackTrace();
				      return u;
			}finally{
			      
			      try{
			         if(orden!=null)
			        	 orden.close();
			      }catch(SQLException se){
			      }
			      try{
			         if(conexion!=null)
			        	 conexion.close();
			      	 }catch(SQLException se){
			         se.printStackTrace();
			      	 }
			}
	}
		
		
			
			public void borrarUsuario(int id){
				Usuario u=new Usuario();
				try{
					orden = (Statement) conexion.createStatement();
			
				    String sql = "DELETE FROM usuario WHERE id= " + " ("+id+")";
				    orden.executeUpdate(sql);
				    System.out.println("Usuario borrado con exito");
				   
				   }catch(SQLException se){
					     
					      se.printStackTrace();
				   }catch(Exception e){
					     
					      e.printStackTrace();
				   }finally{
					      
					      try{
					         if(orden!=null)
					        	 conexion.close();
					      }catch(SQLException se){
					    	  se.printStackTrace();
					      }
					      try{
					         if(conexion!=null)
					        	 conexion.close();
					      	 }catch(SQLException se){
					         se.printStackTrace();
					      }
					}
			}
			public void mostrarUsuarios(){
				
				
				ResultSet rs;
				Usuario u=new Usuario();
				try{
					
					orden = (Statement) conexion.createStatement();
			
				    String sql = "SELECT * FROM usuario ORDER BY id,nombre,apellido1,apellido2,edad";
				    rs = orden.executeQuery(sql);
				    
				    while(rs.next()){
				    	 u.setUserid(rs.getInt("id"));
				    	 u.setNombre(rs.getString("nombre"));
					      u.setApellido1(rs.getString("apellido1"));
					      u.setApellido2(rs.getString("apellido2"));
					      u.setEdad(rs.getInt("edad"));
					    
					      System.out.println(u.getUserid()+" "+u.getNombre()+" "+u.getApellido1()+" "+u.getApellido2()+" "+u.getEdad()+"\n");
				    }
				   
				   }catch(SQLException se){
					     
					      se.printStackTrace();
				   }catch(Exception e){
					     
					      e.printStackTrace();
				   }finally{
					      
					      try{
					         if(orden!=null)
					        	 conexion.close();
					      }catch(SQLException se){
					    	  se.printStackTrace();
					      }
					      try{
					         if(conexion!=null)
					        	 conexion.close();
					      	 }catch(SQLException se){
					         se.printStackTrace();
					      }
					}
			}
			public void loginUsuarios(String cuenta, String pass){
				
				ResultSet rs;
				Usuario u=new Usuario();
				boolean log=false;
				try{
					orden = (Statement) conexion.createStatement();
			
				    String sql ="select cuenta, pasword FROM usuarios";
				    rs = orden.executeQuery(sql);
				    while(rs.next())
				    {
				   /* if (rs.getRow()==0)
				    {
				    	System.out.println("vac�o");
				    }*/
				    String p=rs.getString("pasword");
				    if (p.compareTo(pass)==1) {
				    	System.out.println("Esta bien");
				    	log=true;
				    	
				    };
				    }	 
			
				   }catch(SQLException se){
					     
					      se.printStackTrace();
				   }catch(Exception e){
					     
					      e.printStackTrace();
				   }finally{
					      
					      try{
					         if(orden!=null)
					        	 conexion.close();
					      }catch(SQLException se){
					    	  se.printStackTrace();
					      }
					      try{
					         if(conexion!=null)
					        	 conexion.close();
					      	 }catch(SQLException se){
					         se.printStackTrace();
					      }
					}
			}
	public void registroUsuarios(){
	
	
	ResultSet rs;
	Usuario u=new Usuario();
	try{
		
		orden = (Statement) conexion.createStatement();

	    String sql = "SELECT * FROM usuarios ORDER BY id,nombre,apellido1,apellido2,edad";
	    rs = orden.executeQuery(sql);
	    
	    while(rs.next()){
	    	 u.setUserid(rs.getInt("id"));
	    	 u.setNombre(rs.getString("nombre"));
		      u.setApellido1(rs.getString("apellido1"));
		      u.setApellido2(rs.getString("apellido2"));
		      u.setEdad(rs.getInt("edad"));
		    
		      System.out.println(u.getUserid()+" "+u.getNombre()+" "+u.getApellido1()+" "+u.getApellido2()+" "+u.getEdad()+"\n");
	    }
	   
	   }catch(SQLException se){
		     
		      se.printStackTrace();
	   }catch(Exception e){
		     
		      e.printStackTrace();
	   }finally{
		      
		      try{
		         if(orden!=null)
		        	 conexion.close();
		      }catch(SQLException se){
		    	  se.printStackTrace();
		      }
		      try{
		         if(conexion!=null)
		        	 conexion.close();
		      	 }catch(SQLException se){
		         se.printStackTrace();
		      }
		}
}
			
		
}
